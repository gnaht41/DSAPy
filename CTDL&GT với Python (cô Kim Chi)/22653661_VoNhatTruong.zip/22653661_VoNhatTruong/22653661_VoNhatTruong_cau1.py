import random
import time

def generate_and_save_array(filename, size):
    array = [random.randint(1, 1000) for _ in range(size)]
    with open(filename, 'w') as f:
        for num in array:
            f.write(str(num) + '\n')

def read_array(filename):
    with open(filename, 'r') as f:
        return [int(line.strip()) for line in f]

def interchange_sort(arr):
    comparisons = 0
    swaps = 0
    start_time = time.time()
    for i in range(len(arr)):
        for j in range(i + 1, len(arr)):
            comparisons += 1
            if arr[i] > arr[j]:
                arr[i], arr[j] = arr[j], arr[i]
                swaps += 1
    end_time = time.time()
    execution_time = (end_time - start_time) * 1000  
    return execution_time, comparisons, swaps

def bubble_sort(arr):
    comparisons = 0
    swaps = 0
    start_time = time.time()
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            comparisons += 1
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]
                swaps += 1
    end_time = time.time()
    execution_time = (end_time - start_time) * 1000  
    return execution_time, comparisons, swaps

def insertion_sort(arr):
    comparisons = 0
    swaps = 0
    start_time = time.time()
    for i in range(1, len(arr)):
        key = arr[i]
        j = i - 1
        while j >= 0 and key < arr[j]:
            comparisons += 1
            arr[j + 1] = arr[j]
            swaps += 1
            j -= 1
        arr[j + 1] = key
    end_time = time.time()
    execution_time = (end_time - start_time) * 1000  
    return execution_time, comparisons, swaps

def selection_sort(arr):
    comparisons = 0
    swaps = 0
    start_time = time.time()
    for i in range(len(arr)):
        min_idx = i
        for j in range(i+1, len(arr)):
            comparisons += 1
            if arr[j] < arr[min_idx]:
                min_idx = j
        arr[i], arr[min_idx] = arr[min_idx], arr[i]
        swaps += 1
    end_time = time.time()
    execution_time = (end_time - start_time) * 1000  
    return execution_time, comparisons, swaps

def quick_sort(arr):
    comparisons = 0
    swaps = 0
    start_time = time.time()
    
    def partition(arr, low, high):
        nonlocal comparisons, swaps
        pivot = arr[high]
        i = low - 1
        for j in range(low, high):
            comparisons += 1
            if arr[j] < pivot:
                i += 1
                arr[i], arr[j] = arr[j], arr[i]
                swaps += 1
        arr[i + 1], arr[high] = arr[high], arr[i + 1]
        swaps += 1
        return i + 1

    def quick_sort_helper(arr, low, high):
        if low < high:
            pi = partition(arr, low, high)
            quick_sort_helper(arr, low, pi - 1)
            quick_sort_helper(arr, pi + 1, high)

    quick_sort_helper(arr, 0, len(arr) - 1)

    end_time = time.time()
    execution_time = (end_time - start_time) * 1000  
    return execution_time, comparisons, swaps

def display_results(algorithm_name, execution_time, comparisons, swaps):
    print(f"Thuật toán sắp xếp: {algorithm_name}")
    print(f"Thời gian thực thi: {execution_time:.2f} mili giây")
    print(f"Số lần so sánh: {comparisons}")
    print(f"Số lần hoán đổi: {swaps}\n")

def menu():
    print("Menu:")
    print("1. Đổi chỗ trực tiếp (Interchange sort)")
    print("2. Nổi bọt (Bubble sort)")
    print("3. Chèn trực tiếp (Insertion sort)")
    print("4. Chọn trực tiếp (Selection sort)")
    print("5. Dựa trên phân hoạch (Quick sort)")
    print("0. Thoát")

def main():
    filename = "mang1.int"
    generate_and_save_array(filename, 40000)

    while True:
        menu()
        choice = input("Chọn thuật toán (0-5): ")

        if choice == '0':
            print("Kết thúc chương trình.")
            break

        if choice not in ['1', '2', '3', '4', '5']:
            print("Lựa chọn không hợp lệ, vui lòng chọn lại.")
            continue

        arr = read_array(filename)
        if choice == '1':
            algorithm_name = "Đổi chỗ trực tiếp (Interchange sort)"
            execution_time, comparisons, swaps = interchange_sort(arr)
            display_results(algorithm_name, execution_time, comparisons, swaps)
        elif choice == '2':
            algorithm_name = "Nổi bọt (Bubble sort)"
            execution_time, comparisons, swaps = bubble_sort(arr)
            display_results(algorithm_name, execution_time, comparisons, swaps)
        elif choice == '3':
            algorithm_name = "Chèn trực tiếp (Insertion sort)"
            execution_time, comparisons, swaps = insertion_sort(arr)
            display_results(algorithm_name, execution_time, comparisons, swaps)
        elif choice == '4':
            algorithm_name = "Chọn trực tiếp (Selection sort)"
            execution_time, comparisons, swaps = selection_sort(arr)
            display_results(algorithm_name, execution_time, comparisons, swaps)
        elif choice == '5':
            algorithm_name = "Dựa trên phân hoạch (Quick sort)"
            execution_time, comparisons, swaps = quick_sort(arr)
            display_results(algorithm_name, execution_time, comparisons, swaps)

if __name__ == "__main__":
    main()
