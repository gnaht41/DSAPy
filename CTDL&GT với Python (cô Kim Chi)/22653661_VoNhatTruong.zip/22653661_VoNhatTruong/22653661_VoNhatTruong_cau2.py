class TrangSuc:
    def __init__(self, ma, ten, gia, xuat_xu):
        self.ma = ma
        self.ten = ten
        self.gia = gia
        self.xuat_xu = xuat_xu

    def hien_thi_thong_tin(self):
        print(f'Mã: {self.ma}, Tên: {self.ten}, Giá: {self.gia}, Xuất xứ: {self.xuat_xu}')


class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class DanhSachTrangSuc:
    def __init__(self):
        self.head = None
        self.tail = None

    def them_trang_suc(self, trang_suc_moi):
        current = self.head
        while current:
            if current.data.ma == trang_suc_moi.ma:
                print("Trùng khóa chính, vui lòng nhập lại!")
                return
            current = current.next
        new_node = Node(trang_suc_moi)
        if not self.head:
            self.head = new_node
            self.tail = new_node
        else:
            self.tail.next = new_node
            self.tail = new_node

    def hien_thi_danh_sach(self):
        current = self.head
        while current:
            current.data.hien_thi_thong_tin()
            current = current.next

    def tim_phan_tu_theo_khoa_chinh(self, ma_can_tim):
        current = self.head
        while current:
            if current.data.ma == ma_can_tim:
                current.data.hien_thi_thong_tin()
                return
            current = current.next
        print("Không tìm thấy phần tử có khoá chính là", ma_can_tim)

    def sap_xep_theo_khoa_chinh(self):
        if not self.head:
            return
        current_outer = self.head
        while current_outer:
            min_node = current_outer
            current_inner = current_outer.next
            while current_inner:
                if current_inner.data.ma < min_node.data.ma:
                    min_node = current_inner
                current_inner = current_inner.next
            current_outer.data, min_node.data = min_node.data, current_outer.data
            current_outer = current_outer.next

    def xoa_theo_khoa_chinh(self, ma_can_xoa):
        current = self.head
        previous = None
        while current:
            if current.data.ma == ma_can_xoa:
                if previous:
                    previous.next = current.next
                    if not current.next:
                        self.tail = previous
                else:
                    self.head = current.next
                return
            previous = current
            current = current.next
        print("Không tìm thấy phần tử có khoá chính là", ma_can_xoa)

    def xoa_dau(self):
        if not self.head:
            print("Danh sách rỗng!")
            return
        self.head = self.head.next

    def xoa_cuoi(self):
        if not self.head:
            print("Danh sách rỗng!")
            return
        current = self.head
        previous = None
        while current.next:
            previous = current
            current = current.next
        if previous:
            previous.next = None
            self.tail = previous
        else:
            self.head = None

    def tao_stack(self):
        stack = []
        current = self.head
        while current:
            if int(current.data.ma) % 2 == 0:
                stack.append(current.data)
            current = current.next
        return stack


def print_menu():
    menu_options = {
        1: 'Thêm trang sức vào danh sách',
        2: 'Xuất danh sách các phần tử',
        3: 'Tìm phần tử có khoá chính',
        4: 'Sắp xếp các phần tử theo khoá chính',
        5: 'Xoá phần tử theo khoá chính',
        6: 'Xoá đầu danh sách',
        7: 'Xoá cuối danh sách',
        8: 'Khởi tạo stack và xuất dữ liệu',
        'Khác': 'Thoát chương trình'
    }
    for key in menu_options.keys():
        print(key, '--', menu_options[key])


def main():
    danh_sach_trang_suc = DanhSachTrangSuc()

    while True:
        print_menu()
        user_choice = input('Nhập lựa chọn: ')

        if user_choice == '1':
            ma = int(input("Nhập mã: "))
            ten = input("Nhập tên: ")
            gia = float(input("Nhập giá: "))
            xuat_xu = input("Nhập xuất xứ: ")
            trang_suc_moi = TrangSuc(ma, ten, gia, xuat_xu)
            danh_sach_trang_suc.them_trang_suc(trang_suc_moi)
        elif user_choice == '2':
            print("Danh sách các phần tử:")
            danh_sach_trang_suc.hien_thi_danh_sach()
        elif user_choice == '3':
            ma_can_tim = int(input("Nhập khoá chính cần tìm: "))
            danh_sach_trang_suc.tim_phan_tu_theo_khoa_chinh(ma_can_tim)
        elif user_choice == '4':
            danh_sach_trang_suc.sap_xep_theo_khoa_chinh()
            print("Danh sách sau khi sắp xếp:")
            danh_sach_trang_suc.hien_thi_danh_sach()
        elif user_choice == '5':
            ma_can_xoa = int(input("Nhập khoá chính cần xoá: "))
            danh_sach_trang_suc.xoa_theo_khoa_chinh(ma_can_xoa)
        elif user_choice == '6':
            danh_sach_trang_suc.xoa_dau()
            print("Phần tử đầu danh sách đã được xoá.")
        elif user_choice == '7':
            danh_sach_trang_suc.xoa_cuoi()
            print("Phần tử cuối danh sách đã được xoá.")
        elif user_choice == '8':
            stack = danh_sach_trang_suc.tao_stack()
            print("Dữ liệu trong stack:")
            for item in stack:
                item.hien_thi_thong_tin()
        elif user_choice.lower() == 'khác':
            print("Kết thúc chương trình.")
            break
        else:
            print("Lựa chọn không hợp lệ! Vui lòng thử lại.")


if __name__ == "__main__":
    main()
