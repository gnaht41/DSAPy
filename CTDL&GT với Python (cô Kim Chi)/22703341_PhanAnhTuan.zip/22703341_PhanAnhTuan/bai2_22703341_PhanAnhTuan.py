class VeGuiXe:
    def __init__(self, ma_ve, bien_so_xe, loai_xe, gio_gui, gio_lay, gia_ve):
        self.ma_ve = ma_ve
        self.bien_so_xe = bien_so_xe
        self.loai_xe = loai_xe
        self.gio_gui = gio_gui
        self.gio_lay = gio_lay
        self.gia_ve = gia_ve

    def display(self):
        print(f"Mã vé: {self.ma_ve}")
        print(f"Biển số xe: {self.bien_so_xe}")
        print(f"Loại xe: {self.loai_xe}")
        print(f"Giờ gửi: {self.gio_gui}")
        print(f"Giờ lấy: {self.gio_lay}")
        print(f"Giá vé: {self.gia_ve}")


class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class LinkedList:
    def __init__(self):
        self.head = None

    def append(self, data):
        if not self.head:
            self.head = Node(data)
            return

        current = self.head
        while current.next:
            current = current.next
        current.next = Node(data)

    def display(self):
        current = self.head
        while current:
            current.data.display()
            current = current.next

    def search(self, ma_ve):
        current = self.head
        while current:
            if current.data.ma_ve == ma_ve:
                return current
            current = current.next
        return None

    def remove_head(self):
        if not self.head:
            print("Danh sách rỗng, không thể xóa.")
            return
        self.head = self.head.next

    def remove_tail(self):
        if not self.head:
            print("Danh sách rỗng, không thể xóa.")
            return
        current = self.head
        prev = None
        while current.next:
            prev = current
            current = current.next
        if prev:
            prev.next = None
        else:
            self.head = None

    def remove_by_ma_ve(self, ma_ve):
        current = self.head
        prev = None
        while current:
            if current.data.ma_ve == ma_ve:
                if prev:
                    prev.next = current.next
                else:
                    self.head = current.next
                return
            prev = current
            current = current.next
        print(f"Không tìm thấy vé gửi xe có mã {ma_ve} để xóa.")

    def sort_by_ma_ve(self):
        if not self.head or not self.head.next:
            return

        current = self.head
        while current.next:
            next_node = current.next
            while next_node:
                if current.data.ma_ve > next_node.data.ma_ve:
                    current.data, next_node.data = next_node.data, current.data
                next_node = next_node.next
            current = current.next


class Stack:
    def __init__(self):
        self.stack = []

    def push(self, data):
        self.stack.append(data)

    def pop(self):
        if self.stack:
            return self.stack.pop()
        else:
            return None

    def display(self):
        print("Stack contents:")
        for data in self.stack:
            data.display()

# Menu chương trình
menu_options = {
    1: 'Tạo danh sách vé gửi xe',
    2: 'Thêm vé gửi xe mới',
    3: 'Xuất danh sách vé gửi xe',
    4: 'Tìm vé gửi xe theo mã',
    5: 'Xóa vé gửi xe theo mã (xóa đầu)',
    6: 'Xóa vé gửi xe theo mã (xóa cuối)',
    7: 'Xóa vé gửi xe theo mã',
    8: 'Sắp xếp danh sách vé gửi xe theo mã',
    9: 'Khởi tạo Stack và xuất dữ liệu',
    10: 'Thoát chương trình'
}

dsVeGuiXe = LinkedList()
stack = Stack()

while True:
    print("\nMenu:")
    for key in menu_options:
        print(key, '-', menu_options[key])

    choice = int(input("Nhập lựa chọn của bạn: "))

    if choice == 1:
        while True:
            ma_ve = input("Nhập mã vé (nhập '0' để kết thúc): ")
            if ma_ve == '0':
                break
            if dsVeGuiXe.search(ma_ve):
                print("Vé gửi xe đã tồn tại.")
            else:
                bien_so_xe = input("Nhập biển số xe: ")
                loai_xe = input("Nhập loại xe: ")
                gio_gui = input("Nhập giờ gửi: ")
                gio_lay = input("Nhập giờ lấy: ")
                gia_ve = float(input("Nhập giá vé: "))
                ve_gui_xe = VeGuiXe(ma_ve, bien_so_xe, loai_xe, gio_gui, gio_lay, gia_ve)
                dsVeGuiXe.append(ve_gui_xe)
                print('Đã thêm mới vé gửi xe thành công.')

    elif choice == 2:
        ma_ve = input("Nhập mã vé: ")
        if dsVeGuiXe.search(ma_ve):
            print("Vé gửi xe đã tồn tại.")
        else:
            bien_so_xe = input("Nhập biển số xe: ")
            loai_xe = input("Nhập loại xe: ")
            gio_gui = input("Nhập giờ gửi: ")
            gio_lay = input("Nhập giờ lấy: ")
            gia_ve = float(input("Nhập giá vé: "))
            ve_gui_xe = VeGuiXe(ma_ve, bien_so_xe, loai_xe, gio_gui, gio_lay, gia_ve)
            dsVeGuiXe.append(ve_gui_xe)
            print('Đã thêm mới vé gửi xe thành công.')

    elif choice == 3:
        if not dsVeGuiXe.head:
            print('Danh sách vé gửi xe trống.')
        else:
            print('Danh sách các vé gửi xe:')
            dsVeGuiXe.display()

    elif choice == 4:
        ma_ve = input("Nhập mã vé cần tìm: ")
        node = dsVeGuiXe.search(ma_ve)
        if node:
            print("Thông tin của vé gửi xe có mã", ma_ve)
            node.data.display()
        else:
            print("Không tìm thấy vé gửi xe có mã", ma_ve)

    elif choice == 5:
        dsVeGuiXe.remove_head()
        print("Đã xóa phần tử đầu của danh sách.")

    elif choice == 6:
        dsVeGuiXe.remove_tail()
        print("Đã xóa phần tử cuối của danh sách.")

    elif choice == 7:
        ma_ve = input("Nhập mã vé cần xóa:")
        dsVeGuiXe.remove_by_ma_ve(ma_ve)

    elif choice == 8:
        dsVeGuiXe.sort_by_ma_ve()
        print("Danh sách các vé gửi xe sau khi sắp xếp:")
        dsVeGuiXe.display()

    elif choice == 9:
        current = dsVeGuiXe.head
        while current:
            if int(current.data.ma_ve) % 2 == 0:
                stack.push(current.data)
            current = current.next

        print("Các vé gửi xe có mã chia hết cho 2 (Stack):")
        stack.display()

    elif choice == 10:
        print("Thoát chương trình.")
        break

    else:
        print("Lựa chọn không hợp lệ. Vui lòng chọn lại.")
