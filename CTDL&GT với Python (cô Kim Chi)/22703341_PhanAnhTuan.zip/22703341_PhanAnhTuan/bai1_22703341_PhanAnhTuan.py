import random
import time

# Tạo mảng ngẫu nhiên có 20 phần tử và lưu vào tệp tin
def random_arr_and_save(size=40000, min_a=1, max_a=100, filename="mang1.int"):
    array = [random.randint(min_a, max_a) for _ in range(size)]
    with open(filename, "w") as file:
        for element in array:
            file.write(str(element) + "\n")
    return array

# Phần còn lại của mã không thay đổi

# In mảng 
def print_arr(array):
    print('[', end=" ")
    for element in array:
        print(element, end=" ")
    print("]")

# Phương pháp Đổi chỗ trực tiếp (Interchange Sort)
def InterchangeSort(array):
    n = len(array)
    comparisons = 0
    swaps = 0
    start_time = time.perf_counter()
    for i in range(n):
        for j in range(i + 1, n):
            comparisons += 1
            if array[i] > array[j]:
                array[i], array[j] = array[j], array[i]
                swaps += 1
    end_time = time.perf_counter()
    execution_time = (end_time - start_time) * 1000
    return array, comparisons, swaps, execution_time

# Phương pháp Nổi bọt (Bubble sort)
def BubbleSort(array):
    n = len(array)
    comparisons = 0
    swaps = 0
    start_time = time.perf_counter()
    for i in range(n - 1):
        for j in range(n - 1, 0, -1):
            comparisons += 1
            if array[j] < array[j-1]:
                array[j-1], array[j] = array[j], array[j-1]
                swaps += 1
    end_time = time.perf_counter()
    execution_time = (end_time - start_time) * 1000
    return array, comparisons, swaps, execution_time

# Phương pháp Chèn trực tiếp (Insertion sort)
def InsertionSort(array):
    n = len(array)
    comparisons = 0
    swaps = 0
    start_time = time.perf_counter()
    for i in range(1, n):
        x = array[i]
        pos = i
        while pos > 0 and x < array[pos - 1]:
            comparisons += 1
            array[pos] = array[pos-1]
            pos = pos - 1
            swaps += 1
        array[pos] = x
    end_time = time.perf_counter()
    execution_time = (end_time - start_time) * 1000
    return array, comparisons, swaps, execution_time

# Phương pháp Chọn trực tiếp (Selection sort)
def SelectionSort(array):
    n = len(array)
    comparisons = 0
    swaps = 0
    start_time = time.perf_counter()
    for i in range(0, n):
        min_idx = i
        for j in range(i + 1, n):
            comparisons += 1
            if array[j] < array[min_idx]:
                min_idx = j
        if min_idx != i:
            array[i], array[min_idx] = array[min_idx], array[i]
            swaps += 1
    end_time = time.perf_counter()
    execution_time = (end_time - start_time) * 1000
    return array, comparisons, swaps, execution_time

# Phương pháp dựa trên phân hoạch (Quick sort)
def QuickSort(array, left=None, right=None):
    if left is None:
        left = 0
    if right is None:
        right = len(array) - 1
    comparisons = 0
    swaps = 0
    start_time = time.perf_counter()
    
    def partition(array, left, right, comparisons, swaps):
        pivot = array[right]
        i = left - 1
        for j in range(left, right):
            comparisons += 1
            if array[j] <= pivot:
                i = i + 1
                array[i], array[j] = array[j], array[i]
                swaps += 1
        array[i+1], array[right] = array[right], array[i+1]
        swaps += 1
        return (i + 1, comparisons, swaps)  # Trả về tuple chứa các giá trị
    
    def quick_sort_helper(array, left, right):
        nonlocal comparisons, swaps
        if left < right:
            result = partition(array, left, right, comparisons, swaps)  # Nhận lại tuple từ hàm partition
            pi, comparisons, swaps = result  # Giải nén tuple để lấy các giá trị trả về
            quick_sort_helper(array, left, pi - 1)
            quick_sort_helper(array, pi + 1, right)
    
    quick_sort_helper(array, left, right)
    
    end_time = time.perf_counter()
    execution_time = (end_time - start_time) * 1000
    return array, comparisons, swaps, execution_time

def menu():
    print('1. Phương pháp Đổi chỗ trực tiếp (Interchange sort)')  
    print("2. Phương pháp Nổi bọt (Bubble Sort)")
    print("3. Phương pháp Chèn trực tiếp (Insertion Sort)")
    print("4. Phương pháp Chọn trực tiếp (Selection Sort)")
    print("5. Phương pháp dựa trên phân hoạch (Quick Sort)")
    print("0. Thoát")

def main():
    while True:
        array = random_arr_and_save()
        arr_cop = array.copy()  # Sao chép mảng ban đầu lại 

        menu()

        user_choice = int(input('Nhập tùy chọn: '))
        if user_choice == 0:
            print('Thoát chương trình. Bye bye!!!')
            break

        if user_choice == 1:
            print("===========Interchange Sort===========")
            sorted_array, comparisons, swaps, execution_time = InterchangeSort(arr_cop)
            print(f'Mảng đã được sắp xếp: {sorted_array}\nSố lần so sánh: {comparisons}\nSố lần hoán vị: {swaps}\nThời gian thực thi: {execution_time} mili giây\n')
            print()

        elif user_choice == 2:
            print("===========Bubble Sort===========")
            sorted_array, comparisons, swaps, execution_time = BubbleSort(arr_cop)
            print(f'Mảng đã được sắp xếp: {sorted_array}\nSố lần so sánh: {comparisons}\nSố lần hoán vị: {swaps}\nThời gian thực thi: {execution_time} mili giây\n')
            print()
        elif user_choice == 3:
            print("===========Insertion Sort===========")
            sorted_array, comparisons, swaps, execution_time = InsertionSort(arr_cop)
            print(f'Mảng đã được sắp xếp: {sorted_array}\nSố lần so sánh: {comparisons}\nSố lần hoán vị: {swaps}\nThời gian thực thi: {execution_time} mili giây\n')
            print()
        elif user_choice == 4:
            print("===========Selection Sort===========")
            sorted_array, comparisons, swaps, execution_time = SelectionSort(arr_cop)
            print(f'Mảng đã được sắp xếp: {sorted_array}\nSố lần so sánh: {comparisons}\nSố lần hoán vị: {swaps}\nThời gian thực thi: {execution_time} mili giây\n')
            print()
        elif user_choice == 5:
            left = 0
            right = len(array) - 1 
            print("===========Quick Sort===========")
            sorted_array, comparisons, swaps, execution_time = QuickSort(arr_cop, left, right)  
            print(f'Mảng đã được sắp xếp: {sorted_array}\nSố lần so sánh: {comparisons}\nSố lần hoán vị: {swaps}\nThời gian thực thi: {execution_time} mili giây\n')
        else: 
            print ('Yêu cầu không hợp lệ, vui lòng chọn lại!!')
            break

if __name__ == "__main__":
    main()
