from bt3dslk import * 
def main():
    danh_sach_sv = []

    while True:
        menu()
        lua_chon = input("Nhap lua chon cua ban: ")

        if lua_chon == "1":
            masv = input("Nhap MaSV: ")
            ten_sv = input("Nhap TenSV: ")
            mon_hoc = input("Nhap MonHoc: ")
            diem = float(input("Nhap Diem: "))
            sv = SinhVien(masv, ten_sv, mon_hoc, diem)
            chen_sv_cuoi_danh_sach(danh_sach_sv, sv)

        elif lua_chon == "2":
            sap_xep_theo_diem(danh_sach_sv)
            print("Danh sach da duoc sap xep theo thu tu tang dan cua Diem.")

        elif lua_chon == "3":
            masv = input("Nhap MaSV: ")
            ten_sv = input("Nhap TenSV: ")
            mon_hoc = input("Nhap MonHoc: ")
            diem = float(input("Nhap Diem: "))
            sv = SinhVien(masv, ten_sv, mon_hoc, diem)
            chen_sv_da_sap_xep(danh_sach_sv, sv)
            print("Da chen sinh vien vao danh sach da sap xep.")

        elif lua_chon == "4":
            x = float(input("Nhap gia tri x: "))
            danh_sach_diem_lon_hon_x = lay_danh_sach_diem_lon_hon_x(danh_sach_sv, x)
            print(f"Danh sach sinh vien co Diem lon hon {x}:")
            in_danh_sach(danh_sach_diem_lon_hon_x)

        elif lua_chon == "5":
            k = int(input("Nhap so sinh vien can tim: "))
            k_sinh_vien_cao_nhat = tim_k_sinh_vien_cao_nhat(danh_sach_sv, k)
            print(f"{k} sinh vien co Diem cao nhat:")
            in_danh_sach(k_sinh_vien_cao_nhat)

        elif lua_chon == "6":
            x = float(input("Nhap gia tri x: "))
            loai_bo_sv_nho_hon_x(danh_sach_sv, x)
            print(f"Danh sach sau khi loai bo sinh vien co Diem nho hon {x}:")
            in_danh_sach(danh_sach_sv)

        elif lua_chon == "7":
            danh_sach_sv_moi = []
            n = int(input("Nhap so luong sinh vien can them vao danh sach moi: "))
            for i in range(n):
                masv = input("Nhap MaSV: ")
                ten_sv = input("Nhap TenSV: ")
                mon_hoc = input("Nhap MonHoc: ")
                diem = float(input("Nhap Diem: "))
                sv = SinhVien(masv, ten_sv, mon_hoc, diem)
                danh_sach_sv_moi.append(sv)

            danh_sach_sv = hop_nhat_danh_sach(danh_sach_sv, danh_sach_sv_moi)
            print("Danh sach sau khi hop nhat:")
            in_danh_sach(danh_sach_sv)

        elif lua_chon == "8":
            print("Danh sach sinh vien:")
            in_danh_sach(danh_sach_sv)

        elif lua_chon == "9":
            ten_file = input("Nhap ten file (bao gom ca duong dan neu can): ")
            ghi_danh_sach_vao_file(danh_sach_sv, ten_file)
            print(f"Danh sach sinh vien da duoc ghi vao file {ten_file}.")

        elif lua_chon == "0":
            print("Ket thuc chuong trinh.")
            break

        else:
            print("Lua chon khong hop le. Vui long thu lai.")


if __name__ == "__main__":
    main()
