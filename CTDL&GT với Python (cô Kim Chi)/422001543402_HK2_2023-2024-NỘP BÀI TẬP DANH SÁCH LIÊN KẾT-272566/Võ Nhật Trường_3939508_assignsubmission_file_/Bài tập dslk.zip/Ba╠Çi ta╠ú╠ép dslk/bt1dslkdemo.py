from bt1dslk import *
def main():
    danh_sach_lien_ket = DanhSachLienKet()

    while True:
        input_str = input("Nhap mot so nguyen (nhan Enter de ket thuc): ")

        if input_str == "":
            break

        try:
            so_nguyen = int(input_str)
            danh_sach_lien_ket.them(so_nguyen)
        except ValueError:
            print("Vui long nhap so nguyen.")

    print("Danh sach:")
    danh_sach_lien_ket.hien_thi()

    print(f"1. So luong phan tu trong danh sach: {danh_sach_lien_ket.so_luong()}")
    print(f"2. Tong gia tri cua cac so trong danh sach: {danh_sach_lien_ket.tong_gia_tri()}")
    print(f"3. Gia tri lon nhat trong danh sach: {danh_sach_lien_ket.gia_tri_lon_nhat()}")
    print(f"4. Gia tri nho nhat trong danh sach: {danh_sach_lien_ket.gia_tri_nho_nhat()}")

    danh_sach_tang_dan = danh_sach_lien_ket.sap_xep_tang_dan()
    print("5. Danh sach sap xep theo thu tu tang dan:")
    danh_sach_tang_dan.hien_thi()

    danh_sach_giam_dan = danh_sach_lien_ket.sap_xep_giam_dan()
    print("6. Danh sach sap xep theo thu tu giam dan:")
    danh_sach_giam_dan.hien_thi()

    danh_sach_chan = danh_sach_lien_ket.gia_tri_chan()
    print("7. Danh sach cac phan tu co gia tri chan:")
    danh_sach_chan.hien_thi()

    x = int(input("8. Nhap gia tri X can tim: "))
    vi_tri = danh_sach_lien_ket.tim_gia_tri(x)
    if vi_tri != -1:
        print(f"Phan tu co gia tri {x} duoc tim thay tai vi tri {vi_tri}.")
    else:
        print(f"Khong tim thay phan tu co gia tri {x} trong danh sach.")


if __name__ == "__main__":
    main()
