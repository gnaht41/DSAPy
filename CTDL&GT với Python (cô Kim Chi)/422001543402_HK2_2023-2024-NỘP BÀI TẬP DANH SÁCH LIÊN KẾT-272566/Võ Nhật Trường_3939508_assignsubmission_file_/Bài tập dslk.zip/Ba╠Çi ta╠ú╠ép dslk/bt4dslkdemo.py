from bt4dslk import * 
def main_noi_dung():
    danh_sach_noi_dung = []

    while True:
        menu_noi_dung()
        lua_chon = input("Nhap lua chon cua ban: ")

        if lua_chon == "1":
            ma_nd = input("Nhap MaND: ")
            tieu_de = input("Nhap TieuDe: ")
            noi_dung = input("Nhap NoiDung: ")
            nd = NoiDung(ma_nd, tieu_de, noi_dung)
            them_noi_dung(danh_sach_noi_dung, nd)

        elif lua_chon == "2":
            ma_nd = input("Nhap MaND cua noi dung can sua: ")
            tieu_de_moi = input("Nhap TieuDe moi: ")
            noi_dung_moi = input("Nhap NoiDung moi: ")
            if sua_noi_dung(danh_sach_noi_dung, ma_nd, tieu_de_moi, noi_dung_moi):
                print(f"Sua noi dung co MaND {ma_nd} thanh cong.")
            else:
                print(f"Khong tim thay noi dung co MaND {ma_nd}.")

        elif lua_chon == "3":
            ma_nd = input("Nhap MaND cua noi dung can xoa: ")
            if xoa_noi_dung(danh_sach_noi_dung, ma_nd):
                print(f"Xoa noi dung co MaND {ma_nd} thanh cong.")
            else:
                print(f"Khong tim thay noi dung co MaND {ma_nd}.")

        elif lua_chon == "4":
            print("Danh sach noi dung:")
            in_danh_sach_noi_dung(danh_sach_noi_dung)

        elif lua_chon == "5":
            ten_file = input("Nhap ten file (bao gom ca duong dan neu can): ")
            ghi_danh_sach_noi_dung_vao_file(danh_sach_noi_dung, ten_file)
            print(f"Danh sach noi dung da duoc ghi vao file {ten_file}.")

        elif lua_chon == "0":
            print("Quay lai Menu chinh.")
            break

        else:
            print("Lua chon khong hop le. Vui long thu lai.")


if __name__ == "__main__":
    main_noi_dung()
