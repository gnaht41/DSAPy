class NoiDung:
    def __init__(self, ma_nd, tieu_de, noi_dung):
        self.ma_nd = ma_nd
        self.tieu_de = tieu_de
        self.noi_dung = noi_dung

    def __repr__(self):
        return f"NoiDung(MaND={self.ma_nd}, TieuDe={self.tieu_de}, NoiDung={self.noi_dung})"


def them_noi_dung(danh_sach, nd):
    danh_sach.append(nd)


def sua_noi_dung(danh_sach, ma_nd, tieu_de_moi, noi_dung_moi):
    for nd in danh_sach:
        if nd.ma_nd == ma_nd:
            nd.tieu_de = tieu_de_moi
            nd.noi_dung = noi_dung_moi
            return True
    return False


def xoa_noi_dung(danh_sach, ma_nd):
    for nd in danh_sach:
        if nd.ma_nd == ma_nd:
            danh_sach.remove(nd)
            return True
    return False


def in_danh_sach_noi_dung(danh_sach):
    for nd in danh_sach:
        print(nd)


def ghi_danh_sach_noi_dung_vao_file(danh_sach, ten_file):
    with open(ten_file, 'w') as file:
        for nd in danh_sach:
            file.write(f"{nd.ma_nd},{nd.tieu_de},{nd.noi_dung}\n")


def menu_noi_dung():
    print("===== QUAN LY NOI DUNG =====")
    print("1. Them moi noi dung.")
    print("2. Sua noi dung.")
    print("3. Xoa noi dung.")
    print("4. In danh sach noi dung.")
    print("5. Ghi danh sach noi dung ra file txt.")
    print("0. Quay lai")


