from bt2dslk import *
def main():
    danh_sach = DSLienKetDon()

    while True:
        menu()
        lua_chon = input("Nhap lua chon cua ban: ")

        if lua_chon == "1":
            gia_tri = int(input("Nhap gia tri can them: "))
            danh_sach.them_cuoi(gia_tri)
        elif lua_chon == "2":
            gia_tri_moi = int(input("Nhap gia tri moi can them: "))
            gia_tri_hien_tai = int(input("Nhap gia tri hien tai can them truoc: "))
            danh_sach.them_truoc(gia_tri_moi, gia_tri_hien_tai)
        elif lua_chon == "3":
            print("Danh sach:")
            danh_sach.hien_thi()
        elif lua_chon == "4":
            print("Danh sach theo thu tu nguoc:")
            danh_sach.hien_thi_nguoc()
        elif lua_chon == "5":
            min_val, max_val = danh_sach.tim_min_max()
            print(f"Gia tri nho nhat trong danh sach la: {min_val}")
            print(f"Gia tri lon nhat trong danh sach la: {max_val}")
        elif lua_chon == "6":
            tong_am, tong_duong = danh_sach.tinh_tong_am_duong()
            print(f"Tong so am trong danh sach la: {tong_am}")
            print(f"Tong so duong trong danh sach la: {tong_duong}")
        elif lua_chon == "7":
            tich = danh_sach.tinh_tich()
            print(f"Tich cac so trong danh sach la: {tich}")
        elif lua_chon == "8":
            tong_binh_phuong = danh_sach.tinh_tong_binh_phuong()
            print(f"Tong binh phuong cac so trong danh sach la: {tong_binh_phuong}")
        elif lua_chon == "9":
            x = int(input("Nhap gia tri X: "))
            print(f"Cac so nguyen to cua {x} trong danh sach la:")
            danh_sach.xuat_so_nguyen_to(x)
        elif lua_chon == "10":
            x = int(input("Nhap gia tri X: "))
            print(f"Cac uoc so cua {x} trong danh sach la:")
            danh_sach.xuat_uoc_so(x)
        elif lua_chon == "11":
            x = int(input("Nhap gia tri X: "))
            danh_sach.tim_gia_tri_lon_nhat_lon_hon_x(x)
        elif lua_chon == "12":
            danh_sach.xuat_so_nguyen_to_cuoi_cung()
        elif lua_chon == "13":
            dem_so_nguyen_to = danh_sach.dem_so_nguyen_to()
            print(f"So luong so nguyen to trong danh sach la: {dem_so_nguyen_to}")
        elif lua_chon == "14":
            if danh_sach.kiem_tra_sap_tang():
                print("Danh sach da sap tang.")
            else:
                print("Danh sach chua sap tang.")
        elif lua_chon == "15":
            if danh_sach.kiem_tra_doi_xung():
                print("Danh sach doi xung.")
            else:
                print("Danh sach khong doi xung.")
        elif lua_chon == "16":
            danh_sach.xoa_cuoi()
            print("Phan tu cuoi cung da duoc xoa.")
        elif lua_chon == "17":
            danh_sach.xoa_dau()
            print("Phan tu dau tien da duoc xoa.")
        elif lua_chon == "18":
            danh_sach.huy_danh_sach()
            print("Toan bo danh sach da duoc huy.")
        elif lua_chon == "0":
            print("Ket thuc chuong trinh.")
            break
        else:
            print("Lua chon khong hop le. Vui long thu lai.")


if __name__ == "__main__":
    main()
