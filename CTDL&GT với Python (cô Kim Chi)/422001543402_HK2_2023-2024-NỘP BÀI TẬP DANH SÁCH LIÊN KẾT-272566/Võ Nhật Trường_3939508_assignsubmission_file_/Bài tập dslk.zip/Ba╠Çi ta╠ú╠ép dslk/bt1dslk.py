class Nut:
    def __init__(self, gia_tri):
        self.gia_tri = gia_tri
        self.next = None

class DanhSachLienKet:
    def __init__(self):
        self.dau = None

    def them(self, gia_tri):
        nut_moi = Nut(gia_tri)
        if not self.dau:
            self.dau = nut_moi
            return

        hien_tai = self.dau
        while hien_tai.next:
            hien_tai = hien_tai.next
        hien_tai.next = nut_moi

    def hien_thi(self):
        hien_tai = self.dau
        while hien_tai:
            print(hien_tai.gia_tri, end=" --> ")
            hien_tai = hien_tai.next
        print("None")

    def so_luong(self):
        dem = 0
        hien_tai = self.dau
        while hien_tai:
            dem += 1
            hien_tai = hien_tai.next
        return dem

    def tong_gia_tri(self):
        tong = 0
        hien_tai = self.dau
        while hien_tai:
            tong += hien_tai.gia_tri
            hien_tai = hien_tai.next
        return tong

    def gia_tri_lon_nhat(self):
        if not self.dau:
            return None

        gia_tri_max = self.dau.gia_tri
        hien_tai = self.dau.next
        while hien_tai:
            if hien_tai.gia_tri > gia_tri_max:
                gia_tri_max = hien_tai.gia_tri
            hien_tai = hien_tai.next
        return gia_tri_max

    def gia_tri_nho_nhat(self):
        if not self.dau:
            return None

        gia_tri_min = self.dau.gia_tri
        hien_tai = self.dau.next
        while hien_tai:
            if hien_tai.gia_tri < gia_tri_min:
                gia_tri_min = hien_tai.gia_tri
            hien_tai = hien_tai.next
        return gia_tri_min

    def sap_xep_tang_dan(self):
        gia_tri = []
        hien_tai = self.dau
        while hien_tai:
            gia_tri.append(hien_tai.gia_tri)
            hien_tai = hien_tai.next

        gia_tri.sort()
        danh_sach_sap_xep = DanhSachLienKet()
        for gt in gia_tri:
            danh_sach_sap_xep.them(gt)

        return danh_sach_sap_xep

    def sap_xep_giam_dan(self):
        gia_tri = []
        hien_tai = self.dau
        while hien_tai:
            gia_tri.append(hien_tai.gia_tri)
            hien_tai = hien_tai.next

        gia_tri.sort(reverse=True)
        danh_sach_sap_xep = DanhSachLienKet()
        for gt in gia_tri:
            danh_sach_sap_xep.them(gt)

        return danh_sach_sap_xep

    def gia_tri_chan(self):
        danh_sach_chan = DanhSachLienKet()
        hien_tai = self.dau
        while hien_tai:
            if hien_tai.gia_tri % 2 == 0:
                danh_sach_chan.them(hien_tai.gia_tri)
            hien_tai = hien_tai.next
        return danh_sach_chan

    def tim_gia_tri(self, x):
        hien_tai = self.dau
        vi_tri = 0
        while hien_tai:
            if hien_tai.gia_tri == x:
                return vi_tri
            hien_tai = hien_tai.next
            vi_tri += 1
        return -1

