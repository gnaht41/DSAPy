class Node:
    def __init__(self, value):
        self.value = value
        self.next = None

class DSLienKetDon:
    def __init__(self):
        self.dau = None

    def them_cuoi(self, gia_tri):
        nut_moi = Node(gia_tri)
        if not self.dau:
            self.dau = nut_moi
            return

        hien_tai = self.dau
        while hien_tai.next:
            hien_tai = hien_tai.next
        hien_tai.next = nut_moi

    def them_truoc(self, gia_tri_moi, gia_tri_hien_tai):
        nut_moi = Node(gia_tri_moi)
        if not self.dau:
            print("Danh sach rong, khong the them truoc.")
            return

        if self.dau.value == gia_tri_hien_tai:
            nut_moi.next = self.dau
            self.dau = nut_moi
            return

        hien_tai = self.dau
        while hien_tai.next and hien_tai.next.value != gia_tri_hien_tai:
            hien_tai = hien_tai.next

        if not hien_tai.next:
            print(f"Khong tim thay phan tu {gia_tri_hien_tai} trong danh sach.")
            return

        nut_moi.next = hien_tai.next
        hien_tai.next = nut_moi

    def hien_thi(self):
        hien_tai = self.dau
        while hien_tai:
            print(hien_tai.value, end=" --> ")
            hien_tai = hien_tai.next
        print("None")

    def hien_thi_nguoc(self):
        self._hien_thi_nguoc_recursive(self.dau)
        print("None")

    def _hien_thi_nguoc_recursive(self, nut):
        if nut:
            self._hien_thi_nguoc_recursive(nut.next)
            print(nut.value, end=" --> ")

    def tim_min_max(self):
        if not self.dau:
            return None, None

        min_val = max_val = self.dau.value
        hien_tai = self.dau.next
        while hien_tai:
            if hien_tai.value > max_val:
                max_val = hien_tai.value
            elif hien_tai.value < min_val:
                min_val = hien_tai.value
            hien_tai = hien_tai.next

        return min_val, max_val

    def tinh_tong_am_duong(self):
        tong_am = tong_duong = 0
        hien_tai = self.dau
        while hien_tai:
            if hien_tai.value < 0:
                tong_am += hien_tai.value
            elif hien_tai.value > 0:
                tong_duong += hien_tai.value
            hien_tai = hien_tai.next

        return tong_am, tong_duong

    def tinh_tich(self):
        if not self.dau:
            return 0

        tich = 1
        hien_tai = self.dau
        while hien_tai:
            tich *= hien_tai.value
            hien_tai = hien_tai.next

        return tich

    def tinh_tong_binh_phuong(self):
        tong_binh_phuong = 0
        hien_tai = self.dau
        while hien_tai:
            tong_binh_phuong += hien_tai.value ** 2
            hien_tai = hien_tai.next

        return tong_binh_phuong

    def xuat_so_nguyen_to(self, x):
        hien_tai = self.dau
        while hien_tai:
            if self._la_so_nguyen_to(hien_tai.value, x):
                print(hien_tai.value, end=" ")
            hien_tai = hien_tai.next

    def _la_so_nguyen_to(self, n, x):
        if n < 2:
            return False
        for i in range(2, min(n, x)):
            if n % i == 0:
                return False
        return True

    def xuat_uoc_so(self, x):
        hien_tai = self.dau
        while hien_tai:
            if x % hien_tai.value == 0:
                print(hien_tai.value, end=" ")
            hien_tai = hien_tai.next

    def tim_gia_tri_lon_nhat_lon_hon_x(self, x):
        hien_tai = self.dau
        while hien_tai:
            if hien_tai.value > x:
                print(f"Gia tri dau tien lon hon {x} la {hien_tai.value}.")
                return
            hien_tai = hien_tai.next

        print(f"Khong tim thay gia tri lon hon {x} trong danh sach.")

    def xuat_so_nguyen_to_cuoi_cung(self):
        so_nguyen_to_cuoi_cung = None
        hien_tai = self.dau
        while hien_tai:
            if self._la_so_nguyen_to(hien_tai.value, hien_tai.value):
                so_nguyen_to_cuoi_cung = hien_tai.value
            hien_tai = hien_tai.next

        if so_nguyen_to_cuoi_cung is not None:
            print(f"So nguyen to cuoi cung trong danh sach la {so_nguyen_to_cuoi_cung}.")
        else:
            print("Danh sach khong co so nguyen to.")

    def dem_so_nguyen_to(self):
        dem = 0
        hien_tai = self.dau
        while hien_tai:
            if self._la_so_nguyen_to(hien_tai.value, hien_tai.value):
                dem += 1
            hien_tai = hien_tai.next

        return dem

    def kiem_tra_sap_tang(self):
        hien_tai = self.dau
        while hien_tai and hien_tai.next:
            if hien_tai.value > hien_tai.next.value:
                return False
            hien_tai = hien_tai.next

        return True

    def kiem_tra_doi_xung(self):
        danh_sach_nguoc = DSLienKetDon()
        hien_tai = self.dau
        while hien_tai:
            danh_sach_nguoc.them_cuoi(hien_tai.value)
            hien_tai = hien_tai.next

        hien_tai = self.dau
        hien_tai_nguoc = danh_sach_nguoc.dau
        while hien_tai and hien_tai_nguoc:
            if hien_tai.value != hien_tai_nguoc.value:
                return False
            hien_tai = hien_tai.next
            hien_tai_nguoc = hien_tai_nguoc.next

        return True

    def xoa_cuoi(self):
        if not self.dau:
            print("Danh sach rong, khong the xoa.")
            return

        if not self.dau.next:
            self.dau = None
            return

        hien_tai = self.dau
        while hien_tai.next.next:
            hien_tai = hien_tai.next

        hien_tai.next = None

    def xoa_dau(self):
        if not self.dau:
            print("Danh sach rong, khong the xoa.")
            return

        self.dau = self.dau.next

    def huy_danh_sach(self):
        self.dau = None


def menu():
    print("===== MENU =====")
    print("1. Them mot so vao cuoi danh sach")
    print("2. Them mot so truoc mot so cho truoc")
    print("3. In danh sach")
    print("4. In danh sach theo thu tu nguoc")
    print("5. Tim gia tri nho nhat va lon nhat")
    print("6. Tinh tong so am va so duong")
    print("7. Tinh tich cac so trong danh sach")
    print("8. Tinh tong binh phuong cua cac so")
    print("9. Xuat so nguyen to cua mot so")
    print("10. Xuat uoc so cua mot so")
    print("11. Tim gia tri dau tien lon hon mot so x")
    print("12. Xuat so nguyen to cuoi cung trong danh sach")
    print("13. Dem so luong so nguyen to trong danh sach")
    print("14. Kiem tra danh sach sap tang")
    print("15. Kiem tra xem danh sach co doi xung hay khong")
    print("16. Xoa phan tu cuoi cung")
    print("17. Xoa phan tu dau tien")
    print("18. Huy toan bo danh sach")
    print("0. Thoat")



