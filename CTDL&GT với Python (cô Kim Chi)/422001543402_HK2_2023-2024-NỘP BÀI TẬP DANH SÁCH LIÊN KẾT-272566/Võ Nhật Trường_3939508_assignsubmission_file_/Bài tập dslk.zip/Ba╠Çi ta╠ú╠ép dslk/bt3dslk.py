class SinhVien:
    def __init__(self, masv, ten_sv, mon_hoc, diem):
        self.masv = masv
        self.ten_sv = ten_sv
        self.mon_hoc = mon_hoc
        self.diem = diem

    def __repr__(self):
        return f"SinhVien(MaSV={self.masv}, TenSV={self.ten_sv}, MonHoc={self.mon_hoc}, Diem={self.diem})"


def chen_sv_cuoi_danh_sach(danh_sach, sinh_vien):
    danh_sach.append(sinh_vien)


def sap_xep_theo_diem(danh_sach):
    danh_sach.sort(key=lambda sv: sv.diem)


def chen_sv_da_sap_xep(danh_sach, sinh_vien):
    i = 0
    while i < len(danh_sach) and danh_sach[i].diem < sinh_vien.diem:
        i += 1
    danh_sach.insert(i, sinh_vien)


def lay_danh_sach_diem_lon_hon_x(danh_sach, x):
    return [sv for sv in danh_sach if sv.diem > x]


def tim_k_sinh_vien_cao_nhat(danh_sach, k):
    danh_sach.sort(key=lambda sv: sv.diem, reverse=True)
    return danh_sach[:k]


def loai_bo_sv_nho_hon_x(danh_sach, x):
    danh_sach[:] = [sv for sv in danh_sach if sv.diem >= x]


def hop_nhat_danh_sach(danh_sach1, danh_sach2):
    return danh_sach1 + danh_sach2


def in_danh_sach(danh_sach):
    for sv in danh_sach:
        print(sv)


def ghi_danh_sach_vao_file(danh_sach, ten_file):
    with open(ten_file, 'w') as file:
        for sv in danh_sach:
            file.write(f"{sv.masv},{sv.ten_sv},{sv.mon_hoc},{sv.diem}\n")


def menu():
    print("===== MENU =====")
    print("1. Chèn một học sinh mới vào danh sách cuối cùng.")
    print("2. Sắp xếp danh sách theo thứ tự tăng dần của Điểm")
    print("3. Chèn một học sinh mới vào danh sách đã sắp xếp để có danh sách cũng đã sắp xếp")
    print("4. Lấy danh sách sinh viên có Điểm lớn hơn x.")
    print("5. Tìm kiếm k sinh viên có Điểm cao nhất")
    print("6. Loại bỏ tất cả sinh viên có Điểm nhỏ hơn x.")
    print("7. Hợp nhất vào danh sách sinh viên.")
    print("8. In ra màn hình danh sách sinh viên.")
    print("9. Ghi danh sách học sinh ra file txt.")
    print("0. Thoat")


