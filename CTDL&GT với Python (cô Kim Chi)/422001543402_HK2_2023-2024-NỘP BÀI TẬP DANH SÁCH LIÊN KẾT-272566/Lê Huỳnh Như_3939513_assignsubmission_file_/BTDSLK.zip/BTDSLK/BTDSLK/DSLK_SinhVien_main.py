from DSLK_BT3 import *
def main():
    ds = DanhSachLienKet()
    ds.chen_cuoi("1", "Dat", "Toán", 8.5)
    ds.chen_cuoi("2", "Danh", "Lý", 7.5)
    ds.chen_cuoi("3", "Hieu", "Hóa", 9)

    while True:
        print("1. Chèn sinh viên vào cuối danh sách")
        print("2. Sắp xếp danh sách theo điểm")
        print("3. Chèn sinh viên vào danh sách đã sắp xếp")
        print("4. Lấy danh sách sinh viên có điểm lớn hơn ngưỡng")
        print("5. Lấy k sinh viên có điểm cao nhất")
        print("6. Loại bỏ sinh viên có điểm nhỏ hơn ngưỡng")
        print("7. Hợp nhất danh sách với danh sách khác")
        print("8. Hiển thị danh sách")
        print("9. Ghi danh sách vào tập tin")
        print("0. Thoát chương trình")
        lua_chon = int(input("Chọn một tùy chọn: "))

        if lua_chon == 1:
            masv = input("Nhập Mã sinh viên: ")
            tensv = input("Nhập Tên sinh viên: ")
            monhoc = input("Nhập Môn học: ")
            diem = float(input("Nhập Điểm: "))
            ds.chen_cuoi(masv, tensv, monhoc, diem)
            print("Đã chèn sinh viên mới vào cuối danh sách.")
        elif lua_chon == 2:
            ds.sap_xep_theo_diem()
            print("Đã sắp xếp danh sách theo điểm.")
        elif lua_chon == 3:
            masv = input("Nhập Mã sinh viên: ")
            tensv = input("Nhập Tên sinh viên: ")
            monhoc = input("Nhập Môn học: ")
            diem = float(input("Nhập Điểm: "))
            ds.chen_sap_xep(masv, tensv, monhoc, diem)
            print("Đã chèn sinh viên mới vào danh sách đã sắp xếp.")
        elif lua_chon == 4:
            nguong = float(input("Nhập ngưỡng điểm: "))
            danh_sach_diem_lon_hon = ds.lay_sv_diem_lon_hon(nguong)
            print("Danh sách sinh viên có điểm lớn hơn ngưỡng:")
            danh_sach_diem_lon_hon.hien_thi()
        elif lua_chon == 5:
            k = int(input("Nhập số lượng sinh viên cần lấy: "))
            top_k_sv = ds.lay_k_sv_diem_cao_nhat(k)
            print(f"{k} sinh viên có điểm cao nhất:")
            top_k_sv.hien_thi()
        elif lua_chon == 6:
            nguong = float(input("Nhập ngưỡng điểm: "))
            ds.loai_bo_sv_diem_nho_hon(nguong)
            print("Đã loại bỏ sinh viên có điểm nhỏ hơn ngưỡng.")
        elif lua_chon == 7:
        # Hợp nhất vào danh sách sinh viên
            danh_sach_sv_moi = DanhSachLienKet()
            danh_sach_sv_moi.chen_cuoi("4", "Do Hieu", "Ly", 8.8)
            # Hợp nhất danh sách mới vào danh sách ban đầu
            ds.hop_nhat_danh_sach(danh_sach_sv_moi)

            print("\nDanh sách sinh viên sau khi hợp nhất:")
            ds.hien_thi()
        elif lua_chon == 8:
            print("Danh sách sinh viên:")
            ds.hien_thi()
        elif lua_chon == 9:
            filename = input("Nhập tên tập tin để lưu danh sách: ")
            ds.ghi_vao_tap_tin(filename)
            print(f"Danh sách đã được ghi vào tập tin '{filename}'.")
        elif lua_chon == 0:
            print("Thoát chương trình.")
            break
        else:
            print("Lựa chọn không hợp lệ. Vui lòng chọn lại.")

if __name__ == '__main__':
    main()