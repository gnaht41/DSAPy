class Nut:
    def __init__(self,gia_tri):
        self.gia_tri = gia_tri
        self.nut_ke_tiep = None
        
        
class DSLienKet:
    def __init__(self):
        self.dau = None
        self.duoi = None
        
    def in_ds(self):
        stt = 0
        hien_tai = self.dau
        kq = 'DS['
        while hien_tai!= None:
            stt += 1
            if stt == 1:
                kq += ' ' + str(hien_tai.gia_tri)
            else:
                kq += ' -> ' + str(hien_tai.gia_tri)
            hien_tai = hien_tai.nut_ke_tiep
        kq += ' ]'
        print(kq)
    
    def them(self,gia_tri):
        nut = Nut(gia_tri)
        if self.dau == None:#thêm đầu
            self.dau = nut
            self.duoi = nut
        else:#thêm cuối
            self.duoi.nut_ke_tiep= nut
            self.duoi = nut
            
    def chen(self,chi_muc, gia_tri):
        nut = Nut(gia_tri)
        truoc = None
        hien_tai = self.dau
        i = 0
        while i < chi_muc and hien_tai != None:
            i+=1
            truoc = hien_tai
            hien_tai = hien_tai.nut_ket_tiep
        if truoc == None:
            #thêm vào đầu ds
            nut.nut_ke_tiep = self.dau
            self.dau = nut
            if self.duoi == None:
                self.duoi = nut
        else:
            if hien_tai == None:
                #thêm vào cuối ds
                self.duoi.nut_ke_tiep = nut
                self.duoi = nut
            else:
                # thêm vào giữa
                truoc.nut_ke_tiep = nut
                nut.nut_ke_tiep = hien_tai
    
    def tim(self, gia_tri):
        hien_tai = self.dau
        vi_tri = 0
        while hien_tai != None and hien_tai.gia_tri != gia_tri:
            hien_tai = hien_tai.nut_ke_tiep
            vi_tri += 1
        if hien_tai == None:
            return None
        else:
            return vi_tri
        
    
    def xoa(self, gia_tri):
        hien_tai = self.dau
        truoc = None
        while hien_tai != None and hien_tai.gia_tri != gia_tri:
            truoc = hien_tai
            hien_tai = hien_tai.nut_ke_tiep
        if hien_tai != None:
            # tìm thấy
            if hien_tai == self.dau and hien_tai == self.duoi:
                #xóa pt duy nhat
                self.dau = self.duoi = None
            elif hien_tai == self.dau:
                #xóa pt đầu ko duy nhất
                self.dau = self.dau.nut_ke_tiep
            elif hien_tai == self.duoi:
                # xoa pt đuôi ko duy nhất
                truoc.nut_ke_tiep = None
                self.duoi = truoc
            else:
                truoc.nut_ke_tiep = hien_tai.nut_ke_tiep
            del hien_tai    
    
    def cap_nhat(self, vi_tri, gia_tri):
        hien_tai = self.dau
        i = 0
        while i < vi_tri and hien_tai != None:
            i += 1
            hien_tai = hien_tai.nut_ke_tiep
        if hien_tai != None:
            hien_tai.gia_tri = gia_tri
            
    
    def xoa_het(self):
        hien_tai = self.dau
        self.dau = self.duoi = None
        while hien_tai!= None:
            tam = hien_tai
            hien_tai = hien_tai.nut_ke_tiep
            del tam
    
    def tong_so_luong_pt(self):
        count = 0
        hien_tai = self.dau
        while hien_tai!= None:
            count += 1
            hien_tai = hien_tai.nut_ke_tiep
        return count
    
    def tong_gia_tri(self):
        tong = 0
        hien_tai = self.dau
        while hien_tai != None:
            tong += hien_tai.gia_tri
            hien_tai = hien_tai.nut_ke_tiep
        return tong
    
    def find_min_max(self):
        if not self.dau:
            return None, None
        hien_tai = self.dau
        min_a = max_a = hien_tai.gia_tri
        while hien_tai:
            min_a = min(min_a, hien_tai.gia_tri)
            max_a = max(max_a, hien_tai.gia_tri)
            hien_tai = hien_tai.nut_ke_tiep
        return max_a, min_a
    
    def tim_so_chan(self):
        hien_tai = self.dau
        while hien_tai:
            if hien_tai.gia_tri % 2 == 0:
                print(hien_tai.gia_tri, end=" ")
            hien_tai = hien_tai.nut_ke_tiep
        print()
        
    def tim_so_X(self):
        print("Nhập giá trị muốn tìm:")
        x = int(input())
        hien_tai = self.dau
        while hien_tai:
            if hien_tai.gia_tri == x:
                print("=>",hien_tai.gia_tri, end=" ")
            hien_tai = hien_tai.nut_ke_tiep
        print()


        

