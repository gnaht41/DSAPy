class Nut:
    def __init__(self,gia_tri) :
        self.gia_tri=gia_tri
        self.nut_ke_tiep=None
class DSLienKet1:
    def __init__(self) :
        self.dau=None
        self.duoi=None
    
    def them_dau(self,gia_tri):
        nut=Nut(gia_tri)
        if self.dau==None:
            self.dau=nut
            self.duoi=nut
        else:
            self.duoi.nut_ke_tiep=nut
            self.duoi = nut
    def them_cuoi(self, gia_tri):
        nut = Nut(gia_tri)
        if self.dau is None:
            self.dau = nut
            self.duoi = nut
        else:
            nut.nut_ke_tiep = self.dau
            self.dau = nut      
    def in_ds(self):
        stt=0
        hien_tai=self.dau
        kq='DS['
        while hien_tai != None:
            stt += 1
            if stt == 1:
                kq += ' ' + str(hien_tai.gia_tri)
            else:
                kq+=' -> '+ str(hien_tai.gia_tri)
            #if
            hien_tai=hien_tai.nut_ke_tiep
        #while
        kq+=' ]'
        print(kq)
    def in_ds_nguoc(self):
        def _in_ds_recursive(current, result):
            if current is None:
                return result
            if result != '':
                result = ' -> ' + result
            result = str(current.gia_tri) + result
            return _in_ds_recursive(current.nut_ke_tiep, result)

        kq = _in_ds_recursive(self.dau, '')
        print('DS[ ' + kq + ' ]')
    def Max(self):
        stt=0
        hien_tai=self.dau
        max=hien_tai.gia_tri
        while hien_tai!=None:
            stt+=1
            if max<=hien_tai.gia_tri:
                max=hien_tai.gia_tri
            hien_tai=hien_tai.nut_ke_tiep
        print("Max:",max)
    def Min(self):
        stt=0
        hien_tai=self.dau
        min=hien_tai.gia_tri
        while hien_tai!=None:
            stt+=1
            if min>=hien_tai.gia_tri:
                min=hien_tai.gia_tri
            hien_tai=hien_tai.nut_ke_tiep
        print("Min:",min)
    def TongGiaTri(self):
        kq1=0
        kq2=0
        hien_tai=self.dau
        while hien_tai != None:
            if hien_tai.gia_tri >=0:
                kq1=kq1+hien_tai.gia_tri
            else:
                kq2=kq2+hien_tai.gia_tri
            hien_tai=hien_tai.nut_ke_tiep
        print("Tong gia tri duong:",kq1)
        print("Tong gia tri am:",kq2)
    def TichGiaTri(self):
        tich=1
        hien_tai=self.dau
        while hien_tai != None:
            tich=tich*hien_tai.gia_tri
            hien_tai=hien_tai.nut_ke_tiep
        print("Tich cac gia tri:",tich)
    def TongBinhPhuong(self):
        kq=0
        hien_tai=self.dau
        while hien_tai != None:
            kq=kq+hien_tai.gia_tri*hien_tai.gia_tri
            hien_tai=hien_tai.nut_ke_tiep
        print("Tong binh phuong:",kq)
    def is_prime(self, n):
        if n <= 1:
            return False
        elif n <= 3:
            return True
        elif n % 2 == 0 or n % 3 == 0:
            return False
        i = 5
        while i * i <= n:
            if n % i == 0 or n % (i + 2) == 0:
                return False
            i += 6
        return True
    def Nguyento_cuax(self,x):
        hien_tai = self.dau
        while hien_tai != None:
            if hien_tai.gia_tri<=x:
                if self.is_prime(hien_tai.gia_tri):
                    print( "So nguyen to cua x :",hien_tai.gia_tri, end='\n')
            hien_tai = hien_tai.nut_ke_tiep
    def uoc_so_cua_x(self):
        x = int(input("Nhập số x: "))
        uoc = []
        for i in range(1, x + 1):
            if x % i == 0:
                uoc.append(i)
        print("Ước số của", x, "là:", uoc)
        # Thêm các ước số vào danh sách liên kết
        for u in uoc:
            self.them_cuoi(u)
    def so_lon_hon_x(self):
        x = int(input("Nhập số x: "))
        hien_tai=self.dau
        found = False
        while hien_tai != None:
            if hien_tai.gia_tri>x:
                print('so lon hon x:',hien_tai.gia_tri)
                found = True
            hien_tai=hien_tai.nut_ke_tiep
        if not found:
            print("Không có số nào lớn hơn x.")
    def Nguyento_cuoi(self):
        sontcuoi=None
        hien_tai = self.dau
        while hien_tai != None:
            if self.is_prime(hien_tai.gia_tri):
                sontcuoi=hien_tai.gia_tri
            hien_tai = hien_tai.nut_ke_tiep
        if sontcuoi !=None:
            print("Số nguyên tố cuối cùng trong danh sách:",sontcuoi)
        else:
            print("Không có số nguyên tố trong danh sách.")
    def Sl_nguyento(self):
        stt=0
        hien_tai = self.dau
        while hien_tai != None:
            if self.is_prime(hien_tai.gia_tri):
                stt+=1
            hien_tai = hien_tai.nut_ke_tiep
        print("So luong so nguyen to: ",stt)
    def is_sorted(self):
        hien_tai = self.dau
        while hien_tai != None and hien_tai.nut_ke_tiep != None:
            if hien_tai.gia_tri > hien_tai.nut_ke_tiep.gia_tri:
                print("Khong duoc sap xep tang")
                return False
            hien_tai = hien_tai.nut_ke_tiep
        print("Duoc sap xep tang")
        return True
    def is_symmetric(self):
        current_front = self.dau
        current_back = self.duoi
        while current_front != None and current_back != None:
            if current_front.gia_tri != current_back.gia_tri:
                print("Danh sach khong doi xung")
                return False
            current_front = current_front.nut_ke_tiep
            current_back = current_back.nut_ke_tiep
        print("Danh sach doi xung")
        return True
    def xoa_cuoi(self):
        if self.dau is None:  # Kiểm tra nếu danh sách rỗng
            return
        
        if self.dau.nut_ke_tiep is None:  # Kiểm tra nếu danh sách chỉ có 1 phần tử
            self.dau = None
            self.duoi = None
            return
        
        hien_tai = self.dau
        while hien_tai.nut_ke_tiep.nut_ke_tiep is not None:
            hien_tai = hien_tai.nut_ke_tiep
        
        hien_tai.nut_ke_tiep = None
        self.duoi = hien_tai
    def xoa_dau(self):
        if self.dau is None:  # Kiểm tra nếu danh sách rỗng
            return
        
        if self.dau.nut_ke_tiep is None:  # Kiểm tra nếu danh sách chỉ có 1 phần tử
            self.dau = None
            self.duoi = None
            return
        
        self.dau = self.dau.nut_ke_tiep
    def huy_danh_sach(self):
        self.dau = None
        self.duoi = None


