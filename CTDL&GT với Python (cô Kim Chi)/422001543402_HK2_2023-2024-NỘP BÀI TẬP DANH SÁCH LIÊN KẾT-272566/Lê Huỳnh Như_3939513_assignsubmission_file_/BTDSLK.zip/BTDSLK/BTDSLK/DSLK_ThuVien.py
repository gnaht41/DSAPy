class Node:
    def __init__(self, gia_tri):
        self.gia_tri = gia_tri
        self.nut_ke_tiep = None

class ThuVien:
    def __init__(self):
        self.dau = None
        self.duoi = None

    def them_sach(self, sach):
        nut_moi = Node(sach)
        if not self.dau:
            self.dau = nut_moi
            return

        hien_tai = self.dau
        while hien_tai.nut_ke_tiep:
            hien_tai = hien_tai.nut_ke_tiep
        hien_tai.nut_ke_tiep = nut_moi

    def hien_thi_sach(self):
        hien_tai = self.dau
        while hien_tai:
            print(hien_tai.gia_tri)
            hien_tai = hien_tai.nut_ke_tiep

    def dem_sach_theo_tac_gia(self, tac_gia):
        dem = 0
        hien_tai = self.dau
        while hien_tai:
            if tac_gia in hien_tai.gia_tri['tac_gia']:
                dem += 1
            hien_tai = hien_tai.nut_ke_tiep
        return dem

    def tim_sach_theo_nha_xuat_ban_va_nam(self, nha_xuat_ban, nam_xuat_ban):
        sach = []
        hien_tai = self.dau
        while hien_tai:
            sach_hien_tai = hien_tai.gia_tri
            if sach_hien_tai['nha_xuat_ban'] == nha_xuat_ban and sach_hien_tai['nam_xuat_ban'] == nam_xuat_ban:
                sach.append(sach_hien_tai)
            hien_tai = hien_tai.nut_ke_tiep
        return sach

    def tim_sach_theo_ten(self, ten_sach):
        hien_tai = self.dau
        while hien_tai:
            if hien_tai.gia_tri['ten'] == ten_sach:
                return hien_tai.gia_tri
            hien_tai = hien_tai.nut_ke_tiep
        return None

    def them_sach_sau_khi_tim_kiem(self, ten_sach, sach):
        sach_tim_thay = self.tim_sach_theo_ten(ten_sach)
        if sach_tim_thay:
            print("Sách đã tồn tại.")
            return
        else:
            self.them_sach(sach)

    def xoa_sach_theo_ten(self, tenSach):
        print("Nhập tên sách muốn xóa:")
        tenSach = input()
        if not self.dau:
            print("Thư viện đã trống.")
            return
        if self.dau.tenSach == tenSach:
            self.dau = self.dau.nut_ke_tiep
            return
        hien_tai = self.dau
        while hien_tai.nut_ke_tiep:
            if hien_tai.nut_ke_tiep.tenSach == tenSach:
                hien_tai.nut_ke_tiep = hien_tai.nut_ke_tiep.nut_ke_tiep
                return
            hien_tai= hien_tai.nut_ke_tiep
        print("Không tìm thấy sách có tựa đề này trong thư viện.")
