from bai2 import *

menu_options = {   
    1: 'Thêm một số phần tử vào cuối danh sách',
    2: 'Thêm 1 phần tử vào trước phần tử nào đó',
    3: 'Hiển thị danh sách các phần tử',
    4: 'Hiển thị danh sách các phần tử theo thứ tự ngược',
    5: 'Tìm giá trị lớn nhất, giá trị nhỏ nhất trong danh sách',
    6: 'Tính tổng số âm, tổng số dương trong danh sách',
    7: 'Tính tích các số trong danh sách',
    8: 'Tính tổng bình phương của các số trong danh sách',
    9: 'Nhập x, xuất các số là số nguyên tố của x',
    10: 'Nhập x, xuất các số là ước số của x',
    11: 'Nhập x, tìm giá trị đầu tiên trong danh sách mà >x',
    12: 'Xuất số nguyên tố cuối cùng trong danh sách',
    13: 'Đếm các số nguyên tố',
    14: 'Kiểm tra xem danh sách có phải đã được sắp tăng không',
    15: 'Kiểm tra xem danh sách có các phần tử đối xứng nhau hay không',
    16: 'Xóa phần tử cuối',
    17: 'Xóa phần tử đầu',
    18: 'Hủy toàn bộ danh sách',
    'Others' : 'Exit program'
}
def  print_menu():
    for key in menu_options.keys():
        print(key, '--', menu_options[key])
ds=DSLienKet1()
while(True):
    print_menu()
    userChoice=''
    try:
        userChoice=int(input('Input Choice: '))
    except:
        print('Invalid input, try again.......')
        continue
    if userChoice==1:
        so = int(input("Nhập số muốn thêm: "))
        ds.them_dau(so)
    elif userChoice == 2:
        so = int(input("Nhập số muốn thêm: "))
        ds.them_cuoi(so)
    elif userChoice == 3:
        ds.in_ds()
    elif userChoice == 4:
        ds.in_ds_nguoc()
    elif userChoice == 5:
        ds.Max()
        ds.Min()
    elif userChoice == 6:
        ds.TongGiaTri()
    elif userChoice == 7:
        ds.TichGiaTri()
    elif userChoice == 8:
        ds.TongBinhPhuong()
    elif userChoice == 9:
        so = int(input("Nhập số x: "))
        ds.Nguyento_cuax(so)
    elif userChoice == 10:
        ds.uoc_so_cua_x()
    elif userChoice == 11:
        ds.so_lon_hon_x()
    elif userChoice == 12:
        ds.Nguyento_cuoi()
    elif userChoice == 13:
        ds.Sl_nguyento()
    elif userChoice == 14:
        ds.is_sorted()
    elif userChoice == 15:
        ds.is_symmetric()
    elif userChoice == 16:
        ds.xoa_cuoi()
    elif userChoice == 17:  
        ds.xoa_dau()
    elif userChoice == 18:
        ds.huy_danh_sach()
    else:
        print('Exit program')  
        
    