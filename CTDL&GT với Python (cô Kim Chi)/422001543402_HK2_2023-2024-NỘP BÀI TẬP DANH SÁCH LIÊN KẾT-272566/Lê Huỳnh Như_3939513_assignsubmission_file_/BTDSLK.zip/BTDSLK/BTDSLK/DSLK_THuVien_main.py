from DSLK_ThuVien import *


def main():
    thu_vien = ThuVien()

    while True:
        print("\nMenu:")
        print("1. Thêm sách mới vào cuối danh sách")
        print("2. Thêm sách mới vào đầu danh sách")
        print("3. Hiển thị tất cả các sách")
        print("4. Đếm số lượng sách theo tác giả")
        print("5. Tìm sách theo nhà xuất bản và năm xuất bản")
        print("6. Tìm và thêm sách mới")
        print("7. Xóa sách")

        lua_chon = input("Nhập lựa chọn của bạn: ")

        if lua_chon == '1':
            sach = {
                'ten': input("Nhập tên sách: "),
                'tac_gia': input("Nhập tên tác giả: ").split(','),
                'nha_xuat_ban': input("Nhập tên nhà xuất bản: "),
                'nam_xuat_ban': int(input("Nhập năm xuất bản: ")),
                'gia': int(input("Nhập giá: "))
            }
            thu_vien.them_sach(sach)
        elif lua_chon == '2':
            sach = {
                'ten': input("Nhập tên sách: "),
                'tac_gia': input("Nhập tên tác giả (các tác giả phân cách bằng dấu phẩy): ").split(','),
                'nha_xuat_ban': input("Nhập tên nhà xuất bản: "),
                'nam_xuat_ban': int(input("Nhập năm xuất bản: ")),
                'gia': int(input("Nhập giá: "))
            }
            thu_vien.them_sach_sau_khi_tim_kiem('', sach)
        elif lua_chon == '3':
            thu_vien.hien_thi_sach()
        elif lua_chon == '4':
            tac_gia = input("Nhập tên tác giả: ")
            print("Số lượng sách của", tac_gia, ":", thu_vien.dem_sach_theo_tac_gia(tac_gia))
        elif lua_chon == '5':
            nha_xuat_ban = input("Nhập tên nhà xuất bản: ")
            nam_xuat_ban = int(input("Nhập năm xuất bản: "))
            sach = thu_vien.tim_sach_theo_nha_xuat_ban_va_nam(nha_xuat_ban, nam_xuat_ban)
            print("Sách được xuất bản bởi", nha_xuat_ban, "năm", nam_xuat_ban, ":")
            for i in sach:
                print(i)
        elif lua_chon == '6':
            ten_sach = input("Nhập tên sách: ")
            sach = {
                'ten': ten_sach,
                'tac_gia': input("Nhập tên tác giả (các tác giả phân cách bằng dấu phẩy): ").split(','),
                'nha_xuat_ban': input("Nhập tên nhà xuất bản: "),
                'nam_xuat_ban': int(input("Nhập năm xuất bản:"))}
        
            
            
if __name__ == '__main__':
    main()
