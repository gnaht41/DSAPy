from DSLKdon import *

def main():
    ds = DSLienKet()
    while True:
        print("1. Thêm ")
        print("2. Chèn ")
        print("3. Tìm ")
        print("4. Xóa ")
        print("5. Cập Nhật ")
        print("6. xóa hết ")
        print("7.Số phần tử trong danh sách")
        print("8.In danh sách")
        print("9.Tổng các giá trị trong danh sách")
        print("10.MAX và min")
        print("11.Xuất các phần tử là số chẵn")
        print("12.Xuất phần tử X (nếu X có trong danh sách với X được nhập từ bàn phím")
        choice = int(input("Chọn chức năng: "))
        if choice == 0:
            break
        elif choice ==1:
            num = int(input("nhập phần tử muốn thêm vào danh sách: "))
            ds.them(num)
        elif choice ==2:
            num = int(input("nhập phần tử muốn chèn vào danh sách: "))
            vt = int(input("nhập vị trí: "))
            ds.chen(vt,num)
        elif choice ==3:
            num = int(input("nhập phần tử muốn tìm: "))
            vt = ds.tim(num)
            print(f'so {num} tai vi tri {vt}')
        elif choice ==4:
            num = int(input("nhập phần tử muốn xóa: "))
            ds.xoa(num)
        elif choice ==5:
            vt = int(input("nhập vi trí muốn cập nhật:"))
            num = int(input("nhập phần tử muốn cập nhật:"))
            ds.cap_nhat(vt,num)
        elif choice ==6:
            print("xóa hết danh sách")
            ds.xoa_het()
        elif choice ==7:
            print("tổng số phần tử trong danh sánh là:", ds.tong_so_luong_pt())
        elif choice ==8:
            print("danh sách: ")
            ds.in_ds()
        elif choice ==9:
            print("Tổng giá trị:", ds.tong_gia_tri())
        elif choice ==10:
            print("Giá tri MAX và min:")
            a = ds.find_min_max()
            print(a)
        elif choice ==11:
            print("các phần tử là số chẵn:")
            b = ds.tim_so_chan()
            print(b)
        elif choice ==12:
            print("Tìm phần tử")
            c = ds.tim_so_X()
            print(c)
            


if __name__ == '__main__':
    main()
    

