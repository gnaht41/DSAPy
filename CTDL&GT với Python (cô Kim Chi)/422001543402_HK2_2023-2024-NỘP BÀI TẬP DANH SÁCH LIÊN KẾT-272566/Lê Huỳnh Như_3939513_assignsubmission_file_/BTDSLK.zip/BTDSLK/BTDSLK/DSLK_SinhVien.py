class Nut:
    def __init__(self, masv, tensv, monhoc, diem):
        self.masv = masv
        self.tensv = tensv
        self.monhoc = monhoc
        self.diem = diem
        self.tieptheo = None

class DanhSachLienKet:
    def __init__(self):
        self.dau = None

    def chen_cuoi(self, masv, tensv, monhoc, diem):
        nut_moi = Nut(masv, tensv, monhoc, diem)
        if not self.dau:
            self.dau = nut_moi
        else:
            hien_tai = self.dau
            while hien_tai.tieptheo:
                hien_tai = hien_tai.tieptheo
            hien_tai.tieptheo = nut_moi

    def sap_xep_theo_diem(self):
        if not self.dau or not self.dau.tieptheo:
            return

        hien_tai = self.dau
        while hien_tai:
            chay_vong = hien_tai.tieptheo
            while chay_vong:
                if hien_tai.diem > chay_vong.diem:
                    hien_tai.masv, chay_vong.masv = chay_vong.masv, hien_tai.masv
                    hien_tai.tensv, chay_vong.tensv = chay_vong.tensv, hien_tai.tensv
                    hien_tai.monhoc, chay_vong.monhoc = chay_vong.monhoc, hien_tai.monhoc
                    hien_tai.diem, chay_vong.diem = chay_vong.diem, hien_tai.diem
                chay_vong = chay_vong.tieptheo
            hien_tai = hien_tai.tieptheo

    def chen_sap_xep(self, masv, tensv, monhoc, diem):
        nut_moi = Nut(masv, tensv, monhoc, diem)
        if not self.dau or diem <= self.dau.diem:
            nut_moi.tieptheo = self.dau
            self.dau = nut_moi
        else:
            hien_tai = self.dau
            while hien_tai.tieptheo and hien_tai.tieptheo.diem < diem:
                hien_tai = hien_tai.tieptheo
            nut_moi.tieptheo = hien_tai.tieptheo
            hien_tai.tieptheo = nut_moi

    def lay_sv_diem_lon_hon(self, nguong):
        ket_qua = DanhSachLienKet()
        hien_tai = self.dau
        while hien_tai:
            if hien_tai.diem > nguong:
                ket_qua.chen_cuoi(hien_tai.masv, hien_tai.tensv, hien_tai.monhoc, hien_tai.diem)
            hien_tai = hien_tai.tieptheo
        return ket_qua

    def lay_k_sv_diem_cao_nhat(self, k):
        ket_qua = DanhSachLienKet()
        diem_sv = []
        hien_tai = self.dau
        while hien_tai:
            diem_sv.append(hien_tai.diem)
            hien_tai = hien_tai.tieptheo
        diem_sv.sort(reverse=True)
        hien_tai = self.dau
        for i in range(min(k, len(diem_sv))):
            while hien_tai:
                if hien_tai.diem == diem_sv[i]:
                    ket_qua.chen_cuoi(hien_tai.masv, hien_tai.tensv, hien_tai.monhoc, hien_tai.diem)
                    break
                hien_tai = hien_tai.tieptheo
            hien_tai = self.dau
        return ket_qua

    def loai_bo_sv_diem_nho_hon(self, nguong):
        hien_tai = self.dau
        truoc = None
        while hien_tai:
            if hien_tai.diem < nguong:
                if truoc:
                    truoc.tieptheo = hien_tai.tieptheo
                else:
                    self.dau = hien_tai.tieptheo
            else:
                truoc = hien_tai
            hien_tai = hien_tai.tieptheo

    def hop_nhat_danh_sach(self, danh_sach_moi):
        if not danh_sach_moi.dau:
            return

        if not self.dau:
            self.dau = danh_sach_moi.dau
            return

        hien_tai = self.dau
        while hien_tai.tieptheo:
            hien_tai = hien_tai.tieptheo
        hien_tai.tieptheo = danh_sach_moi.dau
    
    def hien_thi(self):
        hien_tai = self.dau
        while hien_tai:
            print(f"MASV: {hien_tai.masv}, TenSV: {hien_tai.tensv}, MonHoc: {hien_tai.monhoc}, Diem: {hien_tai.diem}")
            hien_tai = hien_tai.tieptheo

    def ghi_vao_tap_tin(self, ten_tap_tin):
        with open(ten_tap_tin, 'w') as file:
            hien_tai = self.dau
            while hien_tai:
                file.write(f"MASV: {hien_tai.masv}, TenSV: {hien_tai.tensv}, MonHoc: {hien_tai.monhoc}, Diem: {hien_tai.diem}\n")
                hien_tai = hien_tai.tieptheo